// index.js

console.log("Hello, index.js!");